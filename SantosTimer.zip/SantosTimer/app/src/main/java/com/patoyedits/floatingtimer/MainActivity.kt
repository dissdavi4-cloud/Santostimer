package com.patoyedits.floatingtimer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 64, 40, 40)
            setBackgroundColor(0xFF101010.toInt())
        }
        val title = TextView(this).apply {
            text = "Santos Timer"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val description = TextView(this).apply {
            text = "Cronômetro flutuante estilo LiveSplit\n\n" +
                "1 toque: iniciar\n" +
                "1 toque (rodando): pausar\n" +
                "1 toque (pausado): continuar\n" +
                "2 toques rápidos: zerar (não inicia)\n\n" +
                "Arraste para mover pela tela."
            textSize = 16f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, 24, 0, 32)
        }
        val startButton = Button(this).apply {
            text = "Ativar cronômetro flutuante"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    val service = Intent(this@MainActivity, TimerOverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(service)
                    } else {
                        startService(service)
                    }
                    finish()
                } else {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        }
        val stopButton = Button(this).apply {
            text = "Fechar cronômetro flutuante"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TimerOverlayService::class.java))
            }
        }
        layout.addView(title)
        layout.addView(description)
        layout.addView(startButton)
        layout.addView(stopButton)
        setContentView(layout)
    }
}
