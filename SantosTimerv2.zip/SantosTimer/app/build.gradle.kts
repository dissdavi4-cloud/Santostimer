plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.patoyedits.floatingtimer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.patoyedits.floatingtimer"
        minSdk = 23
        targetSdk = 33
        versionCode = 4
        versionName = "1.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
