package com.patoyedits.floatingtimer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import java.util.Locale

/** Visual do timer idêntico ao LiveSplit: dígitos verdes em degradê e centésimos menores. */
class LiveSplitTimerView(context: Context) : View(context) {

    enum class State { IDLE, RUNNING, PAUSED }

    private val dm = context.resources.displayMetrics

    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, dm)
    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, dm)

    private var boxWidthPx = dp(280f)
    private var runningColor = 0xFF2FCB56.toInt()

    private val mainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = sp(40f)
    }
    private val decimalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textSize = sp(24f)
    }

    private var mainText = "0"
    private var decimalText = ".00"
    private var state = State.IDLE

    private val padH = dp(16f)
    private val padV = dp(4f)

    init {
        background = GradientDrawable().apply {
            setColor(0xFF0F0F0F.toInt())
            cornerRadius = dp(2f)
            setStroke(dp(1f).toInt().coerceAtLeast(1), 0x22FFFFFF)
        }
        elevation = dp(4f)
    }

    /** Largura da caixa do timer, em dp (o texto fica alinhado à direita). */
    fun setBoxWidthDp(widthDp: Int) {
        boxWidthPx = dp(widthDp.toFloat())
        requestLayout()
        invalidate()
    }

    /** Tamanho da fonte dos números, em sp (os centésimos ficam em 60%). */
    fun setTextSizeSp(sizeSp: Int) {
        mainPaint.textSize = sp(sizeSp.toFloat())
        decimalPaint.textSize = sp(sizeSp * 0.6f)
        updateShader()
        requestLayout()
        invalidate()
    }

    /** Cor personalizada usada enquanto o timer está rodando (antes era verde). */
    fun setRunningColor(color: Int) {
        runningColor = color
        updateShader()
        invalidate()
    }

    private fun blend(from: Int, to: Int, t: Float): Int {
        val a = Color.alpha(from)
        val r = (Color.red(from) + (Color.red(to) - Color.red(from)) * t).toInt()
        val g = (Color.green(from) + (Color.green(to) - Color.green(from)) * t).toInt()
        val b = (Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t).toInt()
        return Color.argb(a, r, g, b)
    }

    fun setState(newState: State) {
        if (state != newState) {
            state = newState
            updateShader()
            invalidate()
        }
    }

    fun setElapsed(ms: Long) {
        val totalCs = ms / 10L
        val cs = totalCs % 100L
        val totalSec = totalCs / 100L
        val s = totalSec % 60L
        val m = (totalSec / 60L) % 60L
        val h = totalSec / 3600L
        val newMain = when {
            h > 0L -> String.format(Locale.US, "%d:%02d:%02d", h, m, s)
            m > 0L -> String.format(Locale.US, "%d:%02d", m, s)
            else -> String.format(Locale.US, "%d", s)
        }
        val newDecimal = String.format(Locale.US, ".%02d", cs)
        val lengthChanged = newMain.length != mainText.length
        mainText = newMain
        decimalText = newDecimal
        if (lengthChanged) requestLayout()
        invalidate()
    }

    private fun updateShader() {
        val (top, bottom) = when (state) {
            State.IDLE -> 0xFFEDEDED.toInt() to 0xFFA6A6A6.toInt()
            State.RUNNING -> blend(runningColor, Color.WHITE, 0.30f) to blend(runningColor, Color.BLACK, 0.15f)
            State.PAUSED -> 0xFFB0B0B0.toInt() to 0xFF6E6E6E.toInt()
        }
        val fm = mainPaint.fontMetrics
        val y0 = padV + 0f
        val y1 = padV + (fm.descent - fm.ascent)
        val shader = LinearGradient(0f, y0, 0f, y1, top, bottom, Shader.TileMode.CLAMP)
        mainPaint.shader = shader
        decimalPaint.shader = shader
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val fm = mainPaint.fontMetrics
        val content = padH * 2 + mainPaint.measureText(mainText) + decimalPaint.measureText(decimalText)
        val w = maxOf(content, boxWidthPx)
        val h = padV * 2 + (fm.descent - fm.ascent)
        setMeasuredDimension(
            resolveSize(w.toInt() + 1, widthMeasureSpec),
            resolveSize(h.toInt() + 1, heightMeasureSpec)
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        updateShader()
    }

    override fun onDraw(canvas: Canvas) {
        val fm = mainPaint.fontMetrics
        val baseline = padV - fm.ascent
        val mainWidth = mainPaint.measureText(mainText)
        val decimalWidth = decimalPaint.measureText(decimalText)
        // Alinhado à direita, como no LiveSplit
        val decimalX = width - padH - decimalWidth
        val mainX = decimalX - mainWidth
        canvas.drawText(mainText, mainX, baseline, mainPaint)
        canvas.drawText(decimalText, decimalX, baseline, decimalPaint)
    }
}
