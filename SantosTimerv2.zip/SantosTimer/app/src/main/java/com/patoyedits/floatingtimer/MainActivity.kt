package com.patoyedits.floatingtimer

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var preview: LiveSplitTimerView
    private lateinit var widthLabel: TextView
    private lateinit var sizeLabel: TextView
    private lateinit var colorLabel: TextView
    private lateinit var seekR: SeekBar
    private lateinit var seekG: SeekBar
    private lateinit var seekB: SeekBar
    private var updatingColorUi = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTextColor(0xFFCCCCCC.toInt())
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun seekBar(max: Int, progress: Int, tint: Int? = null, onChange: (Int) -> Unit) =
        SeekBar(this).apply {
            this.max = max
            this.progress = progress
            if (tint != null && Build.VERSION.SDK_INT >= 21) {
                progressTintList = ColorStateList.valueOf(tint)
                thumbTintList = ColorStateList.valueOf(tint)
            }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) onChange(value)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
            setBackgroundColor(0xFF101010.toInt())
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF101010.toInt())
            addView(layout)
        }

        val title = TextView(this).apply {
            text = "Santos Timer"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val description = TextView(this).apply {
            text = "Cronômetro flutuante estilo LiveSplit\n\n" +
                "1 toque: iniciar / pausar / continuar\n" +
                "2 toques rápidos: zerar (não inicia)\n" +
                "Arraste para mover pela tela."
            textSize = 15f
            setTextColor(0xFFCCCCCC.toInt())
            setPadding(0, dp(12), 0, dp(12))
        }

        // Prévia ao vivo (mostra o timer rodando com a cor escolhida)
        preview = LiveSplitTimerView(this).apply {
            setElapsed(656480L) // 10:56.48
            setState(LiveSplitTimerView.State.RUNNING)
        }
        val previewHolder = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(preview)
        }
        val previewScroll = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(previewHolder)
        }

        // Largura
        val width0 = TimerSettings.widthDp(this)
        widthLabel = label("")
        val widthSeek = seekBar(
            TimerSettings.MAX_WIDTH_DP - TimerSettings.MIN_WIDTH_DP,
            width0 - TimerSettings.MIN_WIDTH_DP
        ) { v ->
            val dpValue = v + TimerSettings.MIN_WIDTH_DP
            TimerSettings.setWidthDp(this, dpValue)
            applyWidth(dpValue)
        }
        applyWidth(width0)

        // Tamanho da fonte
        val size0 = TimerSettings.sizeSp(this)
        sizeLabel = label("")
        val sizeSeek = seekBar(
            TimerSettings.MAX_SIZE_SP - TimerSettings.MIN_SIZE_SP,
            size0 - TimerSettings.MIN_SIZE_SP
        ) { v ->
            val spValue = v + TimerSettings.MIN_SIZE_SP
            TimerSettings.setSizeSp(this, spValue)
            applySize(spValue)
        }
        applySize(size0)

        // Cor personalizada
        val color0 = TimerSettings.color(this)
        colorLabel = label("")
        seekR = seekBar(255, Color.red(color0), 0xFFE53935.toInt()) { onRgbChanged() }
        seekG = seekBar(255, Color.green(color0), 0xFF43A047.toInt()) { onRgbChanged() }
        seekB = seekBar(255, Color.blue(color0), 0xFF1E88E5.toInt()) { onRgbChanged() }

        val presets = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(4))
        }
        val presetColors = intArrayOf(
            0xFF2FCB56.toInt(), // verde
            0xFFFF3B30.toInt(), // vermelho
            0xFF00E5FF.toInt(), // ciano
            0xFFFFD60A.toInt(), // amarelo
            0xFFFF9500.toInt(), // laranja
            0xFFD500F9.toInt(), // magenta
            0xFFFFFFFF.toInt()  // branco
        )
        for (c in presetColors) {
            val swatch = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    setStroke(dp(1), 0x66FFFFFF)
                }
                setOnClickListener { setColorEverywhere(c, updateSeekBars = true) }
            }
            presets.addView(swatch, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        }
        updateColorLabel(color0)
        preview.setRunningColor(color0)

        val startButton = Button(this).apply {
            text = "Ativar cronômetro flutuante"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    val service = Intent(this@MainActivity, TimerOverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        startForegroundService(service)
                    } else {
                        startService(service)
                    }
                    // Não fecha o app: dá pra ajustar largura/cor com o timer já flutuando.
                } else {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                }
            }
        }
        val stopButton = Button(this).apply {
            text = "Fechar cronômetro flutuante"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TimerOverlayService::class.java))
            }
        }
        val resetButton = Button(this).apply {
            text = "Restaurar padrão (verde, 280dp, 40sp)"
            setOnClickListener {
                TimerSettings.setWidthDp(this@MainActivity, TimerSettings.DEFAULT_WIDTH_DP)
                TimerSettings.setSizeSp(this@MainActivity, TimerSettings.DEFAULT_SIZE_SP)
                widthSeek.progress = TimerSettings.DEFAULT_WIDTH_DP - TimerSettings.MIN_WIDTH_DP
                sizeSeek.progress = TimerSettings.DEFAULT_SIZE_SP - TimerSettings.MIN_SIZE_SP
                applyWidth(TimerSettings.DEFAULT_WIDTH_DP)
                applySize(TimerSettings.DEFAULT_SIZE_SP)
                setColorEverywhere(TimerSettings.DEFAULT_COLOR, updateSeekBars = true)
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(previewScroll)
        layout.addView(widthLabel)
        layout.addView(widthSeek)
        layout.addView(sizeLabel)
        layout.addView(sizeSeek)
        layout.addView(colorLabel)
        layout.addView(presets)
        layout.addView(seekR)
        layout.addView(seekG)
        layout.addView(seekB)
        layout.addView(startButton)
        layout.addView(stopButton)
        layout.addView(resetButton)
        setContentView(scroll)
    }

    private fun applyWidth(dpValue: Int) {
        widthLabel.text = "Largura do timer: $dpValue dp"
        preview.setBoxWidthDp(dpValue)
    }

    private fun applySize(spValue: Int) {
        sizeLabel.text = "Tamanho dos números: $spValue sp"
        preview.setTextSizeSp(spValue)
    }

    private fun onRgbChanged() {
        if (updatingColorUi) return
        val c = Color.rgb(seekR.progress, seekG.progress, seekB.progress)
        setColorEverywhere(c, updateSeekBars = false)
    }

    private fun setColorEverywhere(color: Int, updateSeekBars: Boolean) {
        TimerSettings.setColor(this, color)
        preview.setRunningColor(color)
        updateColorLabel(color)
        if (updateSeekBars) {
            updatingColorUi = true
            seekR.progress = Color.red(color)
            seekG.progress = Color.green(color)
            seekB.progress = Color.blue(color)
            updatingColorUi = false
        }
    }

    private fun updateColorLabel(color: Int) {
        colorLabel.text = "Cor dos números (rodando): #%06X".format(color and 0xFFFFFF)
    }
}
