package com.patoyedits.floatingtimer

import android.content.Context
import android.content.SharedPreferences

/** Configurações salvas do Santos Timer (largura, tamanho da fonte e cor dos números). */
object TimerSettings {
    const val PREFS = "santos_timer_prefs"
    const val KEY_WIDTH_DP = "width_dp"
    const val KEY_SIZE_SP = "size_sp"
    const val KEY_COLOR = "color"

    const val MIN_WIDTH_DP = 150
    const val MAX_WIDTH_DP = 500
    const val DEFAULT_WIDTH_DP = 280

    const val MIN_SIZE_SP = 20
    const val MAX_SIZE_SP = 90
    const val DEFAULT_SIZE_SP = 40

    const val DEFAULT_COLOR = 0xFF2FCB56.toInt() // verde padrão

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun widthDp(context: Context) = prefs(context).getInt(KEY_WIDTH_DP, DEFAULT_WIDTH_DP)
    fun sizeSp(context: Context) = prefs(context).getInt(KEY_SIZE_SP, DEFAULT_SIZE_SP)
    fun color(context: Context) = prefs(context).getInt(KEY_COLOR, DEFAULT_COLOR)

    fun setWidthDp(context: Context, v: Int) = prefs(context).edit().putInt(KEY_WIDTH_DP, v).apply()
    fun setSizeSp(context: Context, v: Int) = prefs(context).edit().putInt(KEY_SIZE_SP, v).apply()
    fun setColor(context: Context, v: Int) = prefs(context).edit().putInt(KEY_COLOR, v).apply()
}
