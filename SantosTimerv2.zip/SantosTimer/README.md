# Santos Timer (estilo LiveSplit)

Cronômetro Android nativo em Kotlin, flutuando sobre outros apps, com visual do LiveSplit
(dígitos verdes em degradê, centésimos menores, fundo escuro).

- 1 toque: iniciar. Com ele rodando, 1 toque pausa; pausado, 1 toque continua.
- 2 toques rápidos (até 300 ms): zera e NÃO inicia.
- Arrastar: move o cronômetro pela tela.
- Fechar: botão "Fechar" na notificação ou no app.

Ajustes (no app, valem na hora no timer flutuante): largura do timer (seekbar), tamanho dos números (seekbar) e cor personalizada dos números rodando (RGB + cores prontas).

Cores: cinza = parado/zerado, cor escolhida (padrão verde) = rodando, cinza escuro = pausado.

## Compilar pelo GitHub Actions
Envie o ZIP (ou as pastas do projeto) para a raiz do repositório e crie `.github/workflows/android.yml`.
O APK sai em Actions > Artifacts > SantosTimer-APK.
